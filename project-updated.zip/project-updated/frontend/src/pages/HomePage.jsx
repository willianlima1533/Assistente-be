import React from 'react';
import { useAuth } from '../contexts/AuthContext';

function HomePage() {
  const { user } = useAuth();

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-4xl font-bold mb-4">Welcome to MyApp</h1>
      {user ? (
        <p className="text-lg">
          Hello, <span className="font-semibold">{user.username}</span>! You are logged in.
        </p>
      ) : (
        <p className="text-lg">Please log in to access your dashboard.</p>
      )}
    </div>
  );
}

export default HomePage;
