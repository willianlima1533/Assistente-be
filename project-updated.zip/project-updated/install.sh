#!/bin/bash

set -e # Exit immediately if a command exits with a non-zero status.

# --- Configuration --- 
NODE_VERSION="lts/*"
PNPM_VERSION="latest"
BACKEND_DIR="backend"
FRONTEND_DIR="frontend"

# --- Helper Functions ---
log_info() { echo -e "\033[0;36m[INFO]\033[0m $1"; }
log_success() { echo -e "\033[0;32m[SUCCESS]\033[0m $1"; }
log_warn() { echo -e "\033[0;33m[WARN]\033[0m $1"; }
log_error() { echo -e "\033[0;31m[ERROR]\033[0m $1"; exit 1; }

check_command() {
  command -v "$1" >/dev/null 2>&1
}

# --- OS Detection ---
OS="$(uname -s)"
case "$OS" in
  Linux*)     OS_TYPE=Linux;;
  Darwin*)    OS_TYPE=macOS;;
  CYGWIN*|MINGW32*|MSYS*|MINGW*) OS_TYPE=Windows;;
  *)          OS_TYPE="UNKNOWN:$OS";;
esac

if [[ "$(uname -r)" =~ "microsoft" ]]; then
  OS_TYPE="WSL"
fi

log_info "Sistema Operacional Detectado: $OS_TYPE"

# --- Install NVM and Node.js ---
install_nvm_node() {
  if ! check_command nvm; then
    log_info "NVM não encontrado. Instalando NVM..."
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
    [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion
    log_success "NVM instalado."
  else
    log_info "NVM já está instalado."
  fi

  log_info "Instalando/Usando Node.js $NODE_VERSION..."
  nvm install "$NODE_VERSION" || log_error "Falha ao instalar Node.js $NODE_VERSION"
  nvm use "$NODE_VERSION" || log_error "Falha ao usar Node.js $NODE_VERSION"
  nvm alias default "$NODE_VERSION"
  log_success "Node.js $NODE_VERSION configurado."
}

# --- Install pnpm --- 
install_pnpm() {
  if ! check_command pnpm; then
    log_info "pnpm não encontrado. Instalando pnpm globalmente..."
    npm install -g pnpm || log_error "Falha ao instalar pnpm."
    log_success "pnpm instalado."
  else
    log_info "pnpm já está instalado."
  fi
}

# --- Main Installation Logic ---

log_info "Iniciando instalação do projeto..."

# 1. Install NVM and Node.js
install_nvm_node

# 2. Install pnpm
install_pnpm

# 3. Install dependencies
log_info "Instalando dependências (backend e frontend) com pnpm..."
if [ -d "$BACKEND_DIR" ] && [ -d "$FRONTEND_DIR" ]; then
  pnpm install || log_error "Falha ao instalar dependências."
else
  log_error "Diretórios $BACKEND_DIR ou $FRONTEND_DIR não encontrados. Certifique-se de que está na raiz do projeto."
fi
log_success "Dependências instaladas."

# 4. Database Migrations
log_info "Executando migrações do banco de dados..."
cd "$BACKEND_DIR"
pnpm run migrate || log_error "Falha ao executar migrações. Verifique DATABASE_URL no .env."
cd ..
log_success "Migrações concluídas."

# 5. Database Seeding (Optional)
if [ "$SEED" = "true" ]; then
  log_info "Executando seeding do banco de dados..."
  cd "$BACKEND_DIR"
  pnpm run seed || log_error "Falha ao executar seeding."
  cd ..
  log_success "Seeding concluído."
else
  log_info "Seeding do banco de dados ignorado (SEED não definido como 'true')."
fi

# 6. Build Frontend
log_info "Construindo o frontend..."
cd "$FRONTEND_DIR"
pnpm run build || log_error "Falha ao construir o frontend."
cd ..
log_success "Frontend construído."

# 7. Start Services (Production Mode)
log_info "Iniciando serviços (backend e frontend em modo de produção)..."

# Start backend in background
log_info "Iniciando backend..."
cd "$BACKEND_DIR"
nohup pnpm start:prod > ../backend_prod.log 2>&1 & 
BACKEND_PID=$!
cd ..
log_info "Backend iniciado em segundo plano (PID: $BACKEND_PID). Logs em backend_prod.log"

# Serve frontend build
log_info "Servindo frontend estaticamente..."
# Install 'serve' if not present
if ! check_command serve; then
  log_info "'serve' não encontrado. Instalando globalmente..."
  pnpm add -g serve || log_error "Falha ao instalar 'serve'."
fi

cd "$FRONTEND_DIR"
nohup serve -s build -l 5173 > ../frontend_prod.log 2>&1 & 
FRONTEND_PID=$!
cd ..
log_info "Frontend servido em segundo plano na porta 5173 (PID: $FRONTEND_PID). Logs em frontend_prod.log"

log_success "Projeto instalado e iniciado com sucesso!"
log_info "Acesse o frontend em http://localhost:5173"
log_info "Para parar os serviços, use 'kill $BACKEND_PID $FRONTEND_PID'."
log_info "Verifique os logs em backend_prod.log e frontend_prod.log para detalhes."

