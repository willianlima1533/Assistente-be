const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { db } = require('../db/db');
const { users } = require('../db/schema');
const { eq } = require('drizzle-orm');

const generateToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: '7d',
  });
};

const registerUser = async (username, password) => {
  const hashedPassword = await bcrypt.hash(password, parseInt(process.env.SALT_ROUNDS || 10));
  const newUser = await db.insert(users).values({ username, password: hashedPassword }).returning();
  return { id: newUser[0].id, username: newUser[0].username };
};

const loginUser = async (username, password) => {
  const user = await db.select().from(users).where(eq(users.username, username));
  
  if (user.length === 0) {
    throw new Error('Invalid credentials');
  }

  const isMatch = await bcrypt.compare(password, user[0].password);
  
  if (!isMatch) {
    throw new Error('Invalid credentials');
  }

  const token = generateToken(user[0].id);
  return { id: user[0].id, username: user[0].username, token };
};

module.exports = {
  registerUser,
  loginUser,
};
