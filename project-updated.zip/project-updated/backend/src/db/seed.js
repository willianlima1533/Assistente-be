require('dotenv').config();
const { db } = require('./db');
const { users } = require('./schema');
const bcrypt = require('bcrypt');
const logger = require('../utils/logger');

const seedDatabase = async () => {
  try {
    logger.info('Starting database seeding...');

    const hashedPassword = await bcrypt.hash('password123', 10);

    await db.insert(users).values([
      { username: 'admin', password: hashedPassword },
      { username: 'testuser', password: hashedPassword },
    ]);

    logger.info('Database seeded successfully!');
    process.exit(0);
  } catch (error) {
    logger.error(`Seeding error: ${error.message}`);
    process.exit(1);
  }
};

seedDatabase();
