const { pgTable, serial, text, varchar } = require('drizzle-orm/pg-core');

const users = pgTable('users', {
  id: serial('id').primaryKey(),
  username: varchar('username', { length: 256 }).notNull().unique(),
  password: text('password').notNull(),
});

module.exports = {
  users,
};
