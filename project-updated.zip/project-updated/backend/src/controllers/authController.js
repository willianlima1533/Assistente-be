const { registerUser, loginUser } = require('../services/authService');
const logger = require('../utils/logger');

exports.register = async (req, res, next) => {
  const { username, password } = req.body;
  try {
    const user = await registerUser(username, password);
    logger.info(`User registered: ${user.username}`);
    res.status(201).json({ message: 'User registered successfully', user: { id: user.id, username: user.username } });
  } catch (error) {
    logger.error(`Registration error: ${error.message}`);
    next(error);
  }
};

exports.login = async (req, res, next) => {
  const { username, password } = req.body;
  try {
    const user = await loginUser(username, password);
    logger.info(`User logged in: ${user.username}`);
    res.status(200).json({ message: 'Logged in successfully', user: { id: user.id, username: user.username }, token: user.token });
  } catch (error) {
    logger.error(`Login error: ${error.message}`);
    res.status(400);
    next(error);
  }
};
